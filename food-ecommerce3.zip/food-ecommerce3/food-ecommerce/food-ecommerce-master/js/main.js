// back tot top

let backToTopBtn = document.querySelector('.back-to-top')

window.onscroll = () => {
    if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
        backToTopBtn.style.display = 'flex'
    } else {
        backToTopBtn.style.display = 'none'
    }
}

// top nav menu

let menuItems = document.getElementsByClassName('menu-item')

Array.from(menuItems).forEach((item, index) => {
    item.onclick = (e) => {
        let currMenu = document.querySelector('.menu-item.active')
        currMenu.classList.remove('active')
        item.classList.add('active')
    }
})

// on scroll animation

let scroll = window.requestAnimationFrame || function(callback) {window.setTimeout(callback, 1000/60)}

let elToShow = document.querySelectorAll('.play-on-scroll')

isElInViewPort = (el) => {
    let rect = el.getBoundingClientRect()

    return (
        (rect.top <= 0 && rect.bottom >= 0)
        ||
        (rect.bottom >= (window.innerHeight || document.documentElement.clientHeight) && rect.top <= (window.innerHeight || document.documentElement.clientHeight))
        ||
        (rect.top >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight))
    )
}

loop = () => {
    elToShow.forEach((item, index) => {
        if (isElInViewPort(item)) {
            item.classList.add('start')
        } else {
            item.classList.remove('start')
        }
    })

    scroll(loop)
}

loop()

// mobile nav

let bottomNavItems = document.querySelectorAll('.mb-nav-item')

let bottomMove = document.querySelector('.mb-move-item')

bottomNavItems.forEach((item, index) => {
    item.onclick = (e) => {
        console.log('object')
        let crrItem = document.querySelector('.mb-nav-item.active')
        crrItem.classList.remove('active')
        item.classList.add('active')
        bottomMove.style.left = index * 25 + '%'
    }
})

// CART SECTION

document.getElementById('cart_btn').addEventListener('click', () => {
    document.getElementsByClassName("cart")[0].style.display = "grid";
});
document.getElementById("btn_close").addEventListener('click', () => {
    document.getElementsByClassName("cart")[0].style.display = "none";
});

// CART SECTION (Mobile View)
document.getElementById('mb-cart_btn').addEventListener('click', () => {
    document.getElementsByClassName("cart")[0].style.display = "grid";
});



document.getElementById('add').addEventListener('click', () => {
    let currentCount = parseInt(document.getElementById('quantity').innerHTML);
    let increment = currentCount+1;
    currentCount.value = increment;
    document.getElementById('quantity').textContent=increment;

});
document.getElementById('sub').addEventListener('click', () => {
    let currentCount = parseInt(document.getElementById('quantity').innerHTML);
    if (currentCount > 0) { 
        let decrement = currentCount-1;
        currentCount.value = decrement;
    document.getElementById('quantity').textContent=decrement;
    }
    else if(currentCount == 0){
        document.getElementById('quantity').textContent=0;
    }
    
});

let listProductHTML = document.querySelector('.food-item-wrap');
let listCartHTML = document.querySelector('.cart_list');

let listProducts = [];
let cart = [];

// Display food items 
const addDataToHTML=()=>{
    listProductHTML.innerHTML ='';
    if(listProducts.length >0){
        listProducts.forEach(product =>{
            let newProduct = document.createElement('div');
            newProduct.classList.add('item');
            newProduct.dataset.id = product.id;
            newProduct.innerHTML = ` 
                            <div class="food-item-wrap all">
                    <div class="food-item salad-type">
                        <div class="item-wrap bottom-up play-on-scroll">
                            <div class="item-img">
                                <div class="img-holder bg-img"
                                    style="background-image: url(${product.image});"></div>
                            </div>
                            <div class="item-info">
                                <div>
                                    <h3>
                                        ${product.name}
                                    </h3>
                                    <span>
                                        Rs.${product.price}
                                    </span>
                                </div>
                                <div class="cart-btn">
                                    <i class="bx bx-cart-alt"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                       `;
            listProductHTML.appendChild(newProduct);
        })
    }
}

listProductHTML.addEventListener('click', (event) => {
    let placeClicked = event.target;
    // Check if the clicked element or one of its parents is the cart button
    if (placeClicked.closest('.cart-btn')) {
        // Find the closest .item (product container) and retrieve its data-id
        let productItem = placeClicked.closest('.item');
        let product_id = productItem ? productItem.dataset.id : null;
        if (product_id) {
            // alert(`Product ID: ${product_id}`);
            addToCart(product_id);
        }
    }
});

const addToCart = (product_id) => {
    let positionOfThisProduct = cart.findIndex((value) => value.product_id == product_id);
    if (cart.length <= 0){ // first time run this 
         cart =[{
            product_id:product_id,
            quantity:1
         }]
    }
    else if(positionOfThisProduct < 0){ // check same product is on the cart
        cart.push({
            product_id:product_id,
            quantity:1
        });
    }
    else{
        cart[positionOfThisProduct].quantity = cart[positionOfThisProduct].quantity + 1 // this use to auto increment the quantity  if the same try to add to cart 
                                                                                        
    }
    console.log(cart);
    addCartToHTML();
}

const addCartToHTML = () =>{
    listCartHTML.innerHTML="";
    let totalItemsInCart = 0;
    cart.forEach(cart =>{
        let newCart = document.createElement('div');
        newCart.classList.add('item');
        let positionProduct = listProducts.findIndex((value => value.id == cart.product_id));
        let info = listProducts[positionProduct];
        
        newCart.innerHTML =` 
            <div class="item">
                <div class="image">
                    <img src="${info.image}" alt="" srcset="">
                </div>
                <div class="product_name">
                    <h4>${info.name}</h4>
                </div>
                <div class="product_price">
                    <h5>Rs.${info.price}</h5>
                </div>
                <div class="product_quantity">
                    <span id="sub"><</span>
                    <span id="quantity">0</span>
                    <span id="add">></span>
                </div>
        `;
        
        listCartHTML.appendChild(newCart);
        totalItemsInCart += cart.quantity; 
        
    });

    const cartBtnSpan = document.querySelector("#cart_btn span");
    cartBtnSpan.textContent = totalItemsInCart;
    alert("New Product Added to the Cart.!");
}



const initApp = () => {
    fetch('product.json')
        .then(response => response.json()) 
        .then(data => {
            listProducts = data;
            console.log(listProducts); 
            addDataToHTML();
        })
        .catch(error => {
            console.error('Error fetching the product data:', error);
        });
};

initApp();


// display items based on category
const displayCategoryItems = (category) => {
    listProductHTML.innerHTML = '';
    const categoryItems = listProducts.filter(product => product.type === category);
    console.log(categoryItems)
    if (categoryItems.length > 0) {
        categoryItems.forEach(product => {
            let newProduct = document.createElement('div');
            newProduct.classList.add('item');
            newProduct.dataset.id = product.id;
            newProduct.innerHTML = `
                 <div class="food-item ${category}-type">
                        <div class="item-wrap bottom-up play-on-scroll">
                            <div class="item-img">
                                <div class="img-holder bg-img"
                                    style="background-image: url(${product.image});"></div>
                            </div>
                            <div class="item-info">
                                <div>
                                    <h3>
                                       ${product.name} 
                                    </h3>
                                    <span>
                                        Rs.${product.price}
                                    </span>
                                </div>
                                <div class="cart-btn">
                                    <i class='bx bx-cart-alt'></i>
                                </div>
                            </div>
                        </div>
                    </div>`;
            listProductHTML.appendChild(newProduct);
        });
    } else {
        listProductHTML.innerHTML = `<p>No items available in the ${category} category.</p>`;
    }
};

// Event listeners for each category button
document.getElementById('sambol').addEventListener('click', () => displayCategoryItems('sambol'));
document.getElementById('chutney').addEventListener('click', () => displayCategoryItems('chutney'));
document.getElementById('pickle').addEventListener('click', () => displayCategoryItems('pickle'));
document.getElementById('all').addEventListener('click', () => addDataToHTML());

// Clear Cart --------------
const clearCart = () => {
    cart = [];
    listCartHTML.innerHTML = "";
    const cartBtnSpan = document.querySelector("#cart_btn span");
    cartBtnSpan.textContent = 0;
    alert("All items removed from the cart.");
};

document.getElementById("clearCart").addEventListener("click", clearCart);
